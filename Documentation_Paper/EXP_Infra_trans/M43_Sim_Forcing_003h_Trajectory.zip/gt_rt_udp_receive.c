/*!
 * \file gt_rt_udp_receive.c
 *
 * Simulink GT-RT Target
 *
 * Copyright (C) 2008, GIGATRONIK Stuttgart GmbH
 *
 * $Id: gt_rt_udp_receive.c 236 2010-09-25 10:14:48Z gt\traef $
 *
 * \brief S-Function block to receive messages on udp socket
 */


#define S_FUNCTION_NAME gt_rt_udp_receive
#define S_FUNCTION_LEVEL 2

#include <math.h>
#include <string.h>
#include "simstruc.h"
#include <gt_rt_core/gt_rt_udp_socket.h>
#include <gt_rt_core/gt_rt_error.h>

#define NPARAMS 4
#define URI_IDX 0
#define URI_PARAM(S) ssGetSFcnParam(S, URI_IDX)
#define RECEIVE_BUFFER_SIZE_IDX 1
#define RECEIVE_BUFFER_SIZE_PARAM(S) ssGetSFcnParam(S, RECEIVE_BUFFER_SIZE_IDX)
/*#define LEN_IDX 1 //models max msg length
#define LEN_PARAM(S) ssGetSFcnParam(S, LEN_IDX)*/
#define TIMEOUT_IDX 2 
#define TIMEOUT_PARAM(S) ssGetSFcnParam(S, TIMEOUT_IDX)
#define SAMPLE_TIME_IDX 3
#define SAMPLE_TIME_PARAM(S) ssGetSFcnParam(S, SAMPLE_TIME_IDX) 

#define GT_RT_DEVICE_IDX 0
#define GT_RT_DEVICE(S) (gt_rt_udp_socket*)ssGetPWorkValue(S, GT_RT_DEVICE_IDX)

#define HAS_SET_RECEIVE_BUFFER_IDX 0
#define HAS_SET_RECEIVE_BUFFER(S) ssGetIWorkValue(S, HAS_SET_RECEIVE_BUFFER_IDX)

#define OUT_DATA_IDX 0 //models IDs for output ports
#define OUT_LEN_IDX 1
#define OUT_NEW_DATA_FLAG_IDX 2
#define OUT_SOURCE_IP_IDX 3 //models IDs for output ports
#define OUT_SOURCE_PORT_IDX 4
#define OUT_ERR_IDX 5

#define MDL_CHECK_PARAMETERS
#if defined(MDL_CHECK_PARAMETERS) && defined(MATLAB_MEX_FILE)
static void mdlCheckParameters(SimStruct *S)
{
	gchar uri_string[256];
	gt_rt_uri* uri = NULL;
	real64_T len = 0.0;
	real64_T timeout = 0.0;
	real64_T sample_time = 0.0;
	GError* tmperr = NULL;
	gdouble receive_buffer_size;
  
	if (!mxIsChar(URI_PARAM(S))) { //is uri a string
		tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_UDP_SOCKET,
                         "The 1st S-Function parameter must be a valid GT-RT URI string.");
	}
	if (tmperr == NULL) { //can uri be successfully parsed
		mxGetString(URI_PARAM(S), uri_string, sizeof(uri_string)-1);
			uri = gt_rt_uri_new(uri_string, &tmperr);
			gt_rt_uri_free(uri);		
	}

	if (tmperr == NULL && !(
		mxGetNumberOfElements(RECEIVE_BUFFER_SIZE_PARAM(S)) == 1
		&& (receive_buffer_size = mxGetScalar(RECEIVE_BUFFER_SIZE_PARAM(S))) >= 1.0
		&& receive_buffer_size <= 4294967295.0
        && floor(receive_buffer_size) == receive_buffer_size)) {
      tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_CAN_DEVICE,
		  "The 2rd S-Function parameter must be within the range 1 .. 4294967295.0.", 
		  mxGetScalar(RECEIVE_BUFFER_SIZE_PARAM(S)));
	}

	if (tmperr == NULL && !(mxGetNumberOfElements(TIMEOUT_PARAM(S)) == 1 //timeout is set?
			&& ((timeout = mxGetScalar(TIMEOUT_PARAM(S))) >= 0.0 //timeout > 0
            && floor(timeout) == timeout))) { //timeout is a integer
		tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_S_FUNCTION,
			"The 3nd S-Function parameter must be a scalar integer value >= 0.");   
	}
	if (tmperr == NULL
    && !(mxGetNumberOfElements(SAMPLE_TIME_PARAM(S)) == 1 //sample time set?
         && ((sample_time = mxGetScalar(SAMPLE_TIME_PARAM(S))) > 0.0 //sample time > 0 or sample time == -1
            || sample_time == -1.0))) {
      tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_UDP_SOCKET,
        "The 4th S-Function parameter must be a sample time > 0.0 or -1.0 to inherit the sample time.");   
	}
	if (tmperr != NULL) {
		ssSetErrorStatus(S, tmperr->message);
	}
}
#endif /* MDL_CHECK_PARAMETERS */

static void mdlInitializeSizes(SimStruct *S)
{
  ssSetNumSFcnParams(S, NPARAMS);  /* Number of expected parameters */
#if defined(MATLAB_MEX_FILE)
  if (ssGetNumSFcnParams(S) == ssGetSFcnParamsCount(S)) {
    mdlCheckParameters(S);
    if (ssGetErrorStatus(S) != NULL) {
	    return;
	}
  } else {
    return; /* Parameter mismatch will be reported by Simulink */
  }
#endif
  ssSetSFcnParamNotTunable(S, URI_IDX);
  ssSetSFcnParamNotTunable(S, RECEIVE_BUFFER_SIZE_IDX);
  ssSetSFcnParamNotTunable(S, TIMEOUT_IDX);
  ssSetSFcnParamNotTunable(S, SAMPLE_TIME_IDX);
  
  if (!ssSetNumInputPorts(S, 0)) return;
  if (!ssSetNumOutputPorts(S, 6)) return;

  //outputs data, len, new_data_flag
  ssSetOutputPortDataType(S, OUT_DATA_IDX, SS_UINT8);
  ssSetOutputPortWidth(S, OUT_DATA_IDX, (uint32_T)mxGetScalar(RECEIVE_BUFFER_SIZE_PARAM(S)));
  ssSetOutputPortDataType(S, OUT_LEN_IDX, SS_UINT32);
  ssSetOutputPortWidth(S, OUT_LEN_IDX, 1);
  ssSetOutputPortDataType(S, OUT_NEW_DATA_FLAG_IDX, SS_BOOLEAN);
  ssSetOutputPortWidth(S, OUT_NEW_DATA_FLAG_IDX, 1);
  //outputs source ip, source port
  ssSetOutputPortDataType(S, OUT_SOURCE_IP_IDX, SS_UINT8);
  ssSetOutputPortWidth(S, OUT_SOURCE_IP_IDX, 4);
  ssSetOutputPortDataType(S, OUT_SOURCE_PORT_IDX, SS_UINT16);
  ssSetOutputPortWidth(S, OUT_SOURCE_PORT_IDX, 1);
  //output error
  ssSetOutputPortDataType(S, OUT_ERR_IDX, SS_INT32);
  ssSetOutputPortWidth(S, OUT_ERR_IDX, 1);

  ssSetNumContStates(S, 0); // ?
  ssSetNumDiscStates(S, 0);
  ssSetNumSampleTimes(S, 1);
  ssSetNumRWork(S, 0);
  ssSetNumIWork(S, 1);
  ssSetNumPWork(S, 1);
  ssSetNumModes(S, 0);
  ssSetNumNonsampledZCs(S, 0);
}

#define MDL_START
#if defined(MDL_START)
static void mdlStart(SimStruct *S)
{
	ssSetPWorkValue(S, GT_RT_DEVICE_IDX, NULL);	
	ssSetIWorkValue(S, HAS_SET_RECEIVE_BUFFER_IDX, 0);
}
#endif /* MDL_START */

static void mdlInitializeSampleTimes(SimStruct *S)
{
	ssSetSampleTime(S, 0, mxGetScalar(SAMPLE_TIME_PARAM(S)));
	ssSetOffsetTime(S, 0, 0.0);
	ssSetModelReferenceSampleTimeDefaultInheritance(S);
}

static void mdlOutputs(SimStruct *S, int_T tid)
{
	gchar uri_string[256];
	GError *tmperr = NULL;
	gt_rt_udp_socket* device = GT_RT_DEVICE(S);
	guint32 has_set_receive_buffer = HAS_SET_RECEIVE_BUFFER(S);
	
	guint8 *data = (guint8*)ssGetOutputPortSignal(S, OUT_DATA_IDX);
	guint32 *len = (guint32*)ssGetOutputPortSignal(S, OUT_LEN_IDX);
	boolean_T *new_data_flag = (boolean_T*)ssGetOutputPortSignal(S, OUT_NEW_DATA_FLAG_IDX);

	guint8 *source_ip = (guint8 *) ssGetOutputPortSignal(S, OUT_SOURCE_IP_IDX);
	guint16 *source_port = (guint16 *) ssGetOutputPortSignal(S, OUT_SOURCE_PORT_IDX);

	gint32 *err = (gint32 *) ssGetOutputPortSignal(S, OUT_ERR_IDX);

	guint32 timeout = (guint32)mxGetScalar(TIMEOUT_PARAM(S));

	gt_rt_udp_socket_msg *msg;
	guint32 i;

	int j;
	char *pcm;

	UNUSED_ARG(tid);
	
	*err = 0;
	if (device == NULL) {
		mxGetString(URI_PARAM(S), uri_string, sizeof(uri_string)-1);
		device = gt_rt_udp_socket_get(uri_string, &tmperr);
		if (tmperr == NULL) {
			ssSetPWorkValue(S, GT_RT_DEVICE_IDX, device); //save device for later reusage
		} else {
			*err = tmperr->code;
		}
	}

	if (tmperr == NULL) {
		if (has_set_receive_buffer == 0) {
			//as this is the very first call to mdl_outputs, setup receive buffer of the udp socket
			gt_rt_udp_set_receive_buffer_size(device, (guint32) mxGetScalar(RECEIVE_BUFFER_SIZE_PARAM(S)), &tmperr);
			ssSetIWorkValue(S, HAS_SET_RECEIVE_BUFFER_IDX, 1);
		}
	} else {
		*err = tmperr->code;
	}

	if (tmperr == NULL) {
		msg = gt_rt_udp_socket_receive(device, timeout, &tmperr);
		if (tmperr == NULL) {
			for (i = 0; i < msg->length; ++i) {
				data[i] = msg->msg[i];
			}
			pcm = strtok(msg->ip, ".");
			if (pcm != NULL && msg->new_data_flag == TRUE) {
				for (j = 0; j < 4; j++) {
					source_ip[j] = atoi(pcm);
					pcm = strtok(NULL, ".");
				}
			} else {
				source_ip[0] = 0;
				source_ip[1] = 0;
				source_ip[2] = 0;
				source_ip[3] = 0;
			}

			*source_port = msg->port;
			*len = msg->length;
			*new_data_flag = msg->new_data_flag;
		} else {
			*err = tmperr->code;
		}
	}
}

static void mdlTerminate(SimStruct *S)
{
	if (ssGetPWork(S) != NULL) {
		ssSetPWorkValue(S, GT_RT_DEVICE_IDX, NULL);
	}
}


#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
