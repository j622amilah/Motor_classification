/*!
 * \file gt_rt_can_receive.c
 *
 * Simulink GT-RT Target
 *
 * Copyright (C) 2008, GIGATRONIK Stuttgart GmbH
 *
 * $Id: gt_rt_can_receive.c 236 2010-09-25 10:14:48Z gt\traef $
 *
 * \brief S-Function block to receive messages on CAN device
 */

#define S_FUNCTION_NAME gt_rt_can_receive
#define S_FUNCTION_LEVEL 2

#include <string.h>
#include <math.h>
#include "simstruc.h"
#include <gt_rt_core/gt_rt_can_device.h>
#include <gt_rt_core/gt_rt_error.h>

#define NPARAMS 4

#define URI_IDX 0
#define URI_PARAM(S) ssGetSFcnParam(S, URI_IDX)
#define RECEIVE_ALL_IDS_IDX 1
#define RECEIVE_ALL_IDS_PARAM(S) ssGetSFcnParam(S, RECEIVE_ALL_IDS_IDX)
#define CAN_ID_IDX 2
#define CAN_ID_PARAM(S) ssGetSFcnParam(S, CAN_ID_IDX)
#define SAMPLE_TIME_IDX 3
#define SAMPLE_TIME_PARAM(S) ssGetSFcnParam(S, SAMPLE_TIME_IDX)
#define GT_RT_DEVICE_IDX 0
#define GT_RT_DEVICE(S) (gt_rt_can_device*)ssGetPWorkValue(S, GT_RT_DEVICE_IDX)
#define OUT_CAN_ID_IDX 0
#define OUT_DATA_IDX 1
#define OUT_MFF_IDX 2
#define OUT_DLC_IDX 3
#define OUT_NEW_DATA_FLAG_IDX 4
#define OUT_TIME_STAMP_IDX 5

#define MDL_CHECK_PARAMETERS
#if defined(MDL_CHECK_PARAMETERS) && defined(MATLAB_MEX_FILE)
static void mdlCheckParameters(SimStruct *S)
{
	gchar uri_string[256];
  real64_T receive_all_ids = 0.0;
  real64_T can_id = 0.0;
  real64_T sample_time = 0.0;
	gt_rt_uri* uri = NULL;
  GError* tmperr = NULL;

  if (mxIsChar(URI_PARAM(S))) {
    mxGetString(URI_PARAM(S), uri_string, sizeof(uri_string)-1);
		uri = gt_rt_uri_new(uri_string, &tmperr);
		gt_rt_uri_free(uri);		
  } else {
    tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_CAN_DEVICE,
                         "The 1st S-Function parameter must be a valid GT-RT URI string.");
	}
  if (tmperr == NULL
    && !(mxGetNumberOfElements(RECEIVE_ALL_IDS_PARAM(S)) == 1
         && (receive_all_ids = mxGetScalar(RECEIVE_ALL_IDS_PARAM(S)) >= 0.0
         && receive_all_ids <= 1.0
         && floor(receive_all_ids) == receive_all_ids)))
  {
      tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_CAN_DEVICE,
        "The 2nd S-Function parameter must be true or false.");   
  }
  if (tmperr == NULL
    && !(mxGetNumberOfElements(CAN_ID_PARAM(S)) == 1
         && (can_id = mxGetScalar(CAN_ID_PARAM(S))) >= -1.0
         && can_id <= 536870912.0
         && floor(can_id) == can_id)) {
      tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_CAN_DEVICE,
        "The 3rd S-Function parameter must be a valid CAN ID or -1 to receive all CAN messages.");   
	}
  if (tmperr == NULL
    && !(mxGetNumberOfElements(SAMPLE_TIME_PARAM(S)) == 1
         && ((sample_time = mxGetScalar(SAMPLE_TIME_PARAM(S))) > 0.0
            || sample_time == -1.0))) {
      tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_CAN_DEVICE,
        "The 4th S-Function parameter must be a sample time > 0.0 or -1.0 to inherit the sample time.");   
  }
  if (tmperr != NULL) {
		ssSetErrorStatus(S, tmperr->message);
	}
}
#endif /* MDL_CHECK_PARAMETERS */

static void mdlInitializeSizes(SimStruct *S)
{	
	ssSetNumSFcnParams(S, NPARAMS);  /* Number of expected parameters */
#if defined(MATLAB_MEX_FILE)
  if (ssGetNumSFcnParams(S) == ssGetSFcnParamsCount(S)) {
    mdlCheckParameters(S);
    if (ssGetErrorStatus(S) != NULL) {
      return;
    }
  } else {
    return; /* Parameter mismatch will be reported by Simulink */
  }
#endif
  ssSetSFcnParamNotTunable(S, URI_IDX);
  ssSetSFcnParamNotTunable(S, CAN_ID_IDX);
  
  if (!ssSetNumInputPorts(S, 0)) return;

  if (!ssSetNumOutputPorts(S, 6)) return;
  
  ssSetOutputPortWidth(S, OUT_CAN_ID_IDX, 1);
  ssSetOutputPortDataType(S, OUT_CAN_ID_IDX, SS_INT32);
  ssSetOutputPortWidth(S, OUT_DATA_IDX, 8);
  ssSetOutputPortDataType(S, OUT_DATA_IDX, SS_UINT8);
  ssSetOutputPortWidth(S, OUT_MFF_IDX, 1);
  ssSetOutputPortDataType(S, OUT_MFF_IDX, SS_UINT8);
  ssSetOutputPortWidth(S, OUT_DLC_IDX, 1);
  ssSetOutputPortDataType(S, OUT_DLC_IDX, SS_UINT8);
  ssSetOutputPortWidth(S, OUT_NEW_DATA_FLAG_IDX, 1);
  ssSetOutputPortDataType(S, OUT_NEW_DATA_FLAG_IDX, SS_BOOLEAN);
  ssSetOutputPortWidth(S, OUT_TIME_STAMP_IDX, 1);
  ssSetOutputPortDataType(S, OUT_TIME_STAMP_IDX, SS_UINT32);
  
  ssSetNumContStates(S, 0);
  ssSetNumDiscStates(S, 0);
  ssSetNumSampleTimes(S, 1);
  ssSetNumRWork(S, 0);
  ssSetNumIWork(S, 0);
  ssSetNumPWork(S, 1);
  ssSetNumModes(S, 0);
  ssSetNumNonsampledZCs(S, 0);
}

#define MDL_START
#if defined(MDL_START)
static void mdlStart(SimStruct *S)
{
  ssSetPWorkValue(S, GT_RT_DEVICE_IDX, NULL);
}
#endif /* MDL_START */

static void mdlInitializeSampleTimes(SimStruct *S)
{
  ssSetSampleTime(S, 0, mxGetScalar(SAMPLE_TIME_PARAM(S)));
  ssSetOffsetTime(S, 0, 0.0);
	ssSetModelReferenceSampleTimeDefaultInheritance(S);
}

static void mdlOutputs(SimStruct *S, int_T tid) 
{	
  gchar uri_string[256];
  GError* tmperr = NULL;
	gt_rt_can_device* can_device = GT_RT_DEVICE(S);
  gt_rt_can_msg* rx_msg = NULL;
  int32_T* can_id = (int32_T*)ssGetOutputPortSignal(S, OUT_CAN_ID_IDX);
  uint8_T* data = (uint8_T*)ssGetOutputPortSignal(S, OUT_DATA_IDX);
  uint8_T* mff = (uint8_T*)ssGetOutputPortSignal(S, OUT_MFF_IDX);
  uint8_T* dlc = (uint8_T*)ssGetOutputPortSignal(S, OUT_DLC_IDX);
  boolean_T* new_data_flag = (boolean_T*)ssGetOutputPortSignal(S, OUT_NEW_DATA_FLAG_IDX);
  uint32_T* time_stamp = (uint32_T*)ssGetOutputPortSignal(S, OUT_TIME_STAMP_IDX);
  UNUSED_ARG(tid);
  
  if (can_device == NULL) {
    mxGetString(URI_PARAM(S), uri_string, sizeof(uri_string)-1);
    can_device = gt_rt_can_device_get(uri_string, &tmperr);
	  if (tmperr == NULL) {
      ssSetPWorkValue(S, GT_RT_DEVICE_IDX, can_device);
      if (!(gboolean)mxGetScalar(RECEIVE_ALL_IDS_PARAM(S))) {
        gt_rt_can_device_register_rx_msg(can_device, (guint32)mxGetScalar(CAN_ID_PARAM(S)));
      }
    }
    if (tmperr != NULL) {
		  ssSetErrorStatus(S, tmperr->message);
      return;
	  }
  }
  rx_msg = gt_rt_can_device_receive(can_device, 
    (gboolean)mxGetScalar(RECEIVE_ALL_IDS_PARAM(S)),
    (guint32)mxGetScalar(CAN_ID_PARAM(S)),
    &tmperr);
  if (tmperr == NULL) {
    if (rx_msg == NULL) {
      *can_id = -1;
      memset(data, 0, 8);
      *mff = 0;
      *dlc = 0;
      *new_data_flag = 0;
      *time_stamp = 0;
    } else {
      *can_id = (int32_T)rx_msg->id;
      memcpy(data, rx_msg->a_data, 8);
      *mff = rx_msg->mff;
      *dlc = rx_msg->dlc;
      *new_data_flag = rx_msg->new_data_flag;
      rx_msg->new_data_flag = 0;
      *time_stamp = rx_msg->time_stamp;
    }
  } else {
    ssSetErrorStatus(S, tmperr->message);  
  }
}

static void mdlTerminate(SimStruct *S)
{	
  if (ssGetPWork(S) != NULL) {
		ssSetPWorkValue(S, GT_RT_DEVICE_IDX, NULL);
	}
}


#ifdef  MATLAB_MEX_FILE										/* Is this file being compiled as a MEX-file? */
#include "simulink.c"										/* MEX-file interface mechanism */
#else
#include "cg_sfun.h"										/* Code generation registration function */
#endif
