/*!
 * \file gt_rt_can_controller.c
 *
 * Simulink GT-RT Target
 *
 * Copyright (C) 2008, GIGATRONIK Stuttgart GmbH
 *
 * $Id: gt_rt_can_controller.c 323 2011-01-12 10:18:50Z gt\traef $
 *
 * \brief S-Function block to open CAN device
 */

#define S_FUNCTION_NAME gt_rt_can_controller
#define S_FUNCTION_LEVEL 2

#include <string.h>
#include "simstruc.h"
#include <gt_rt_core/gt_rt_can_device.h>
#include <gt_rt_core/gt_rt_error.h>

#define NPARAMS 2
#define URI_IDX 0
#define URI_PARAM(S) ssGetSFcnParam(S, URI_IDX)
#define OPTIONS_IDX 1
#define OPTIONS_PARAM(S) ssGetSFcnParam(S, OPTIONS_IDX)
#define GT_RT_DEVICE_IDX 0
#define GT_RT_DEVICE(S) (gt_rt_can_device*)ssGetPWorkValue(S, GT_RT_DEVICE_IDX)


#define MDL_CHECK_PARAMETERS
#if defined(MDL_CHECK_PARAMETERS) && defined(MATLAB_MEX_FILE)
static void mdlCheckParameters(SimStruct *S)
{	
	gchar uri_string[256];
	gchar option_string[256];
	gt_rt_can_device* can_device = NULL;
  gt_rt_uri* uri = NULL;
	GError* tmperr = NULL;
	
  if (mxIsChar(URI_PARAM(S))) {
    mxGetString(URI_PARAM(S), uri_string, sizeof(uri_string)-1);
		uri = gt_rt_uri_new(uri_string, &tmperr);
		gt_rt_uri_free(uri);		
  } else {
    tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_CAN_DEVICE,
                         "The 1st S-Function parameter must be a valid GT-RT URI string.");
	}
  if (tmperr == NULL) {
    if (mxIsChar(OPTIONS_PARAM(S))) {
      mxGetString(URI_PARAM(S), uri_string, sizeof(uri_string)-1);
	    mxGetString(OPTIONS_PARAM(S), option_string, sizeof(option_string)-1);
	    can_device = gt_rt_can_device_new(uri_string, option_string, &tmperr);
  	  gt_rt_can_device_free(can_device);
    } else {
      tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_CAN_DEVICE,
                         "The 2nd S-Function parameter must be a valid GT-RT device options string.");
	  }
  }
  if (tmperr != NULL)
	{
		ssSetErrorStatus(S, tmperr->message);
	}
}
#endif /* MDL_CHECK_PARAMETERS */

static void mdlInitializeSizes(SimStruct *S)
{
  ssSetNumSFcnParams(S, NPARAMS);  /* Number of expected parameters */
#if defined(MATLAB_MEX_FILE)
  if (ssGetNumSFcnParams(S) == ssGetSFcnParamsCount(S)) {
    mdlCheckParameters(S);
    if (ssGetErrorStatus(S) != NULL) {
      return;
    }
  } else {
    return; /* Parameter mismatch will be reported by Simulink */
  }
#endif
  ssSetSFcnParamNotTunable(S, URI_IDX);
  ssSetSFcnParamNotTunable(S, OPTIONS_IDX);

  if (!ssSetNumInputPorts(S, 0)) return;
  if (!ssSetNumOutputPorts(S, 0)) return;

  ssSetNumContStates(S, 0);
  ssSetNumDiscStates(S, 0);
  ssSetNumSampleTimes(S, 1);
  ssSetNumRWork(S, 0);
  ssSetNumIWork(S, 0);
  ssSetNumPWork(S, 1);
  ssSetNumModes(S, 0);
  ssSetNumNonsampledZCs(S, 0);
  /*
    ssSetOptions(S,
    SS_OPTION_WORKS_WITH_CODE_REUSE |
    SS_OPTION_EXCEPTION_FREE_CODE |
    SS_OPTION_ALLOW_INPUT_SCALAR_EXPANSION |
    SS_OPTION_USE_TLC_WITH_ACCELERATOR);
    ssSetModelReferenceNormalModeSupport(S, MDL_START_AND_MDL_PROCESS_PARAMS_OK);
  */
}

#define MDL_START
#if defined(MDL_START)
static void mdlStart(SimStruct *S)
{
	gt_rt_can_device* can_device = NULL;
	GError* tmperr = NULL;
	gchar uri_string[256];
	gchar option_string[256];

	mxGetString(URI_PARAM(S), uri_string, sizeof(uri_string)-1);
	mxGetString(OPTIONS_PARAM(S), option_string, sizeof(option_string)-1);
	can_device = gt_rt_can_device_new(uri_string, option_string, &tmperr);

	if (tmperr == NULL) {
		gt_rt_can_device_open(can_device, &tmperr);
  }
  if (tmperr == NULL) {
    ssSetPWorkValue(S, GT_RT_DEVICE_IDX, can_device);
  }

  if (tmperr != NULL) {
		ssSetErrorStatus(S, tmperr->message);
	}	
}
#endif /* MDL_START */

static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, 0.0);
    ssSetModelReferenceSampleTimeDefaultInheritance(S);
}

static void mdlOutputs(SimStruct *S, int_T tid)
{
  UNUSED_ARG(tid);
}

static void mdlTerminate(SimStruct *S)
{ 
  GError* tmperr = NULL;

  if (ssGetPWork(S) != NULL && GT_RT_DEVICE(S) != NULL) {
    gt_rt_can_device_close(GT_RT_DEVICE(S), &tmperr);
    gt_rt_can_device_free(GT_RT_DEVICE(S));
    ssSetPWorkValue(S, GT_RT_DEVICE_IDX, NULL);
  }
	if (tmperr != NULL) {
	  ssSetErrorStatus(S, tmperr->message);
  }
}


#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
