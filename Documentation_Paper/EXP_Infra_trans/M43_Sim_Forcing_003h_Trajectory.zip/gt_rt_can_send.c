/*!
 * \file gt_rt_can_send.c
 *
 * Simulink GT-RT Target
 *
 * Copyright (C) 2008, GIGATRONIK Stuttgart GmbH
 *
 * $Id: gt_rt_can_send.c 236 2010-09-25 10:14:48Z gt\traef $
 *
 * \brief S-Function block to send messages on CAN device
 */


#define S_FUNCTION_NAME gt_rt_can_send
#define S_FUNCTION_LEVEL 2

#include <math.h>
#include <string.h>
#include "simstruc.h"
#include <gt_rt_core/gt_rt_can_device.h>
#include <gt_rt_core/gt_rt_error.h>

#define NPARAMS 2
#define URI_IDX 0
#define URI_PARAM(S) ssGetSFcnParam(S, URI_IDX)
#define MFF_IDX 1
#define MFF_PARAM(S) ssGetSFcnParam(S, MFF_IDX)
#define GT_RT_DEVICE_IDX 0
#define GT_RT_DEVICE(S) (gt_rt_can_device*)ssGetPWorkValue(S, GT_RT_DEVICE_IDX)
#define IN_ID_IDX 0
#define IN_DATA_IDX 1

#define MDL_CHECK_PARAMETERS
#if defined(MDL_CHECK_PARAMETERS) && defined(MATLAB_MEX_FILE)
static void mdlCheckParameters(SimStruct *S)
{
	gchar uri_string[256];
	gt_rt_uri* uri = NULL;
  GError* tmperr = NULL;
  real64_T mff = 0;

  if (mxIsChar(URI_PARAM(S))) {
    mxGetString(URI_PARAM(S), uri_string, sizeof(uri_string)-1);
		uri = gt_rt_uri_new(uri_string, &tmperr);
		gt_rt_uri_free(uri);		
  } else {
    tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_CAN_DEVICE,
                         "The 1st S-Function parameter must be a valid GT-RT URI string.");
	}
  if (tmperr == NULL &&
      !(mxGetNumberOfElements(MFF_PARAM(S)) == 1
        && (mff = mxGetScalar(MFF_PARAM(S))) >= 1.0
        && mff <= 7.0
        && floor(mff) == mff)) {
    tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_CAN_DEVICE,
          "The 2nd S-Function parameter must be a valid message frame format ID: "
          "MFF_11_DAT = 1, "
          "MFF_11_RMT = 2, "
          "MFF_29_DAT = 3, "
          "MFF_29_RMT = 4, "
          "MFF_STS_MSG = 5, "
          "MFF_RMT_MASK = 6, "
          "MFF_EXT_MASK = 7");
  }
  if (tmperr != NULL) {
		ssSetErrorStatus(S, tmperr->message);
	}
}
#endif /* MDL_CHECK_PARAMETERS */

static void mdlInitializeSizes(SimStruct *S)
{
  ssSetNumSFcnParams(S, NPARAMS);  /* Number of expected parameters */
#if defined(MATLAB_MEX_FILE)
  if (ssGetNumSFcnParams(S) == ssGetSFcnParamsCount(S)) {
    mdlCheckParameters(S);
    if (ssGetErrorStatus(S) != NULL) 
	  {
	    return;
	  }
  } else {
    return; /* Parameter mismatch will be reported by Simulink */
  }
#endif
  ssSetSFcnParamNotTunable(S, URI_IDX);
  ssSetSFcnParamNotTunable(S, MFF_IDX);

  if (!ssSetNumInputPorts(S, 2)) return;
  ssSetInputPortDataType(S, IN_ID_IDX, SS_UINT32);
  ssSetInputPortWidth(S, IN_ID_IDX, 1);
  ssSetInputPortDataType(S, IN_DATA_IDX, SS_UINT8);
  ssSetInputPortWidth(S, IN_DATA_IDX, DYNAMICALLY_SIZED);
  ssSetInputPortDirectFeedThrough(S, IN_ID_IDX, 1);
  ssSetInputPortDirectFeedThrough(S, IN_DATA_IDX, 1);
	
  if (!ssSetNumOutputPorts(S, 0)) return;

  ssSetNumContStates(S, 0);
  ssSetNumDiscStates(S, 0);
  ssSetNumSampleTimes(S, 1);
  ssSetNumRWork(S, 0);
  ssSetNumIWork(S, 0);
  ssSetNumPWork(S, 1);
  ssSetNumModes(S, 0);
  ssSetNumNonsampledZCs(S, 0);
}

#define MDL_START
#if defined(MDL_START)
static void mdlStart(SimStruct *S)
{
  GError* tmperr = NULL;
	
  ssSetPWorkValue(S, GT_RT_DEVICE_IDX, NULL);
  if (ssGetInputPortWidth(S, IN_DATA_IDX) <= 0 || ssGetInputPortWidth(S, IN_DATA_IDX) > 8) {
    tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_CAN_DEVICE,
                         "The width of port 1 must be between 1 to 8 bytes.");
  }
  if (tmperr != NULL) {
		ssSetErrorStatus(S, tmperr->message);
	}	
}
#endif /* MDL_START */

static void mdlInitializeSampleTimes(SimStruct *S)
{
  ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
  ssSetOffsetTime(S, 0, 0.0);
	ssSetModelReferenceSampleTimeDefaultInheritance(S);
}

static void mdlOutputs(SimStruct *S, int_T tid)
{
  gchar uri_string[256];
  GError* tmperr = NULL;
	gt_rt_can_device* can_device = GT_RT_DEVICE(S);
	InputUInt8PtrsType packet_data = (InputUInt8PtrsType)ssGetInputPortSignalPtrs(S, IN_DATA_IDX); 
	InputUInt32PtrsType can_id = (InputUInt32PtrsType)ssGetInputPortSignalPtrs(S, IN_ID_IDX);
  gt_rt_can_msg tx_msg;
  gint32 i;
  UNUSED_ARG(tid);
	
  if (can_device == NULL) {
    mxGetString(URI_PARAM(S), uri_string, sizeof(uri_string)-1);
    can_device = gt_rt_can_device_get(uri_string, &tmperr);
	  if (tmperr == NULL) {
      ssSetPWorkValue(S, GT_RT_DEVICE_IDX, can_device);
    } else {
      ssSetErrorStatus(S, tmperr->message);
      return;
	  }
  }
  tx_msg.dlc = ssGetInputPortWidth(S, IN_DATA_IDX);
  tx_msg.mff = (guint8)mxGetScalar(MFF_PARAM(S)) - 1;
  tx_msg.id = *can_id[0];
  for (i=0; i<tx_msg.dlc; ++i) {
    tx_msg.a_data[i] = *packet_data[i];
	}
	gt_rt_can_device_send(can_device, &tx_msg, &tmperr);
	if (tmperr != NULL){
		ssSetErrorStatus(S, tmperr->message);
	}
}

static void mdlTerminate(SimStruct *S)
{
	if (ssGetPWork(S) != NULL) {
		ssSetPWorkValue(S, GT_RT_DEVICE_IDX, NULL);
	}
}


#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
