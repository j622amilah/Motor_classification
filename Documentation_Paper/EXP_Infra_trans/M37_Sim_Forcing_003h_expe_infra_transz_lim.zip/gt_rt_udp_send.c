/*!
 * \file gt_rt_udp_send.c
 *
 * Simulink GT-RT Target
 *
 * Copyright (C) 2008, GIGATRONIK Stuttgart GmbH
 *
 * $Id: gt_rt_udp_send.c 236 2010-09-25 10:14:48Z gt\traef $
 *
 * \brief S-Function block to send messages on udp socket
 */


#define S_FUNCTION_NAME gt_rt_udp_send
#define S_FUNCTION_LEVEL 2

#include <math.h>
#include <string.h>
#include "simstruc.h"
#include <gt_rt_core/gt_rt_udp_socket.h>
#include <gt_rt_core/gt_rt_error.h>

#define NPARAMS 2 //models only parameters, not input signals
#define URI_IDX 0 //index of the uri parameter
#define URI_PARAM(S) ssGetSFcnParam(S, URI_IDX)
#define HOSTNAME_IDX 1 //index of the hostname parameter
#define HOSTNAME_PARAM(S) ssGetSFcnParam(S, HOSTNAME_IDX)
#define GT_RT_DEVICE_IDX 0
#define GT_RT_DEVICE(S) (gt_rt_udp_socket*)ssGetPWorkValue(S, GT_RT_DEVICE_IDX)
#define HOSTNAME_STORAGE_IDX 1
#define HOSTNAME_STORAGE(S) (gchar *)ssGetPWorkValue(S, HOSTNAME_STORAGE_IDX)
#define HOSTNAME_STORAGE_LEN 256
/*#define IN_DATA_IDX 0
#define IN_LEN_IDX 1
*/

//input signals
#define IN_IP_IDX 0 //index of ip port
#define IN_PORT_IDX 1 //index of port port
#define IN_DATA_IDX 2 //index of data port
#define IN_LEN_IDX 3 //index of data_length port

#define OUT_ERR_IDX 0 //index of error output port

#define MDL_CHECK_PARAMETERS
#if defined(MDL_CHECK_PARAMETERS) && defined(MATLAB_MEX_FILE)

/* Checks the parameter uri (which is the only parameter)
	Maps to a device */
static void mdlCheckParameters(SimStruct *S)
{
	gchar uri_string[256];
	gt_rt_uri* uri = NULL;
	GError* tmperr = NULL;
  
	if (mxIsChar(URI_PARAM(S))) {
		mxGetString(URI_PARAM(S), uri_string, sizeof(uri_string)-1);
			uri = gt_rt_uri_new(uri_string, &tmperr);
			gt_rt_uri_free(uri);		
	} else {
		tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_UDP_SOCKET,
                         "The 1st S-Function parameter must be a valid GT-RT URI string.");
	}  

	if (!mxIsChar(HOSTNAME_PARAM(S))) {
		tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_UDP_SOCKET,
                         "The hostname parameter has to be a (possibly empty) string.");			
	}
	
	if (tmperr != NULL) {
		ssSetErrorStatus(S, tmperr->message);
	}
}
#endif /* MDL_CHECK_PARAMETERS */

static void mdlInitializeSizes(SimStruct *S)
{
  ssSetNumSFcnParams(S, NPARAMS);  /* Number of expected parameters */
#if defined(MATLAB_MEX_FILE)
  if (ssGetNumSFcnParams(S) == ssGetSFcnParamsCount(S)) {
    mdlCheckParameters(S);
    if (ssGetErrorStatus(S) != NULL) {
	    return;
	}
  } else {
    return; /* Parameter mismatch will be reported by Simulink */
  }
#endif
  ssSetSFcnParamNotTunable(S, URI_IDX); //uri parameter doesn't change
  ssSetSFcnParamNotTunable(S, HOSTNAME_IDX); //hostname parameter doesn't change
  
  if (!ssSetNumInputPorts(S, 4)) return; //set 4 input ports

  //configure input ports
  ssSetInputPortDataType(S, IN_IP_IDX, SS_UINT8);
  ssSetInputPortWidth(S, IN_IP_IDX, 4);

  ssSetInputPortDataType(S, IN_PORT_IDX, SS_UINT16);
  ssSetInputPortWidth(S, IN_PORT_IDX, 1);

  ssSetInputPortDataType(S, IN_DATA_IDX, SS_UINT8);
  ssSetInputPortWidth(S, IN_DATA_IDX, DYNAMICALLY_SIZED);

  ssSetInputPortDataType(S, IN_LEN_IDX, SS_UINT32);
  ssSetInputPortWidth(S, IN_LEN_IDX, 1);


  ssSetInputPortDirectFeedThrough(S, IN_IP_IDX, 1);
  ssSetInputPortDirectFeedThrough(S, IN_PORT_IDX, 1);
  ssSetInputPortDirectFeedThrough(S, IN_DATA_IDX, 1);
  ssSetInputPortDirectFeedThrough(S, IN_LEN_IDX, 1);
	
  if (!ssSetNumOutputPorts(S, 1)) return;
  ssSetOutputPortDataType(S, OUT_ERR_IDX, SS_INT32);
  ssSetOutputPortWidth(S, OUT_ERR_IDX, 1);

  ssSetNumContStates(S, 0);
  ssSetNumDiscStates(S, 0);
  ssSetNumSampleTimes(S, 1);
  ssSetNumRWork(S, 0);
  ssSetNumIWork(S, 0);
  ssSetNumPWork(S, 2);
  ssSetNumModes(S, 0);
  ssSetNumNonsampledZCs(S, 0);
}

#define MDL_START
#if defined(MDL_START)
static void mdlStart(SimStruct *S)
{
	GError* tmperr = NULL;
	
	ssSetPWorkValue(S, GT_RT_DEVICE_IDX, NULL); //save the device id in the work vector
	ssSetPWorkValue(S, HOSTNAME_STORAGE_IDX, NULL); //save the hostname 

	//check whether the specified port width matches the constraints in libgtrt
	//applies only to the dynamically sized vectors (data in this case)
	if (ssGetInputPortWidth(S, IN_DATA_IDX) <= 0) {
		tmperr = g_error_new(GT_RT_ERROR, GT_RT_ERROR_UDP_SOCKET,
                         "The width of port 1 must be greater than 1 bytes.");
	}
	if (tmperr != NULL) {
		ssSetErrorStatus(S, tmperr->message);
	}	
}
#endif /* MDL_START */

#define MDL_SET_INPUT_PORT_DIMENSION_INFO 
static void mdlSetInputPortDimensionInfo(SimStruct *S, int_T port, 
										 const DimsInfo_T *dimsInfo) 
{
	//ssSetErrorStatus(S, "ran into an error\n");
	if (port == IN_DATA_IDX) {

		ssSetInputPortDimensionInfo(S, port, dimsInfo);
	} else {
		ssSetErrorStatus(S, "Unexpected DYNAMICALLY_SIZED parameter index\n");
	}
}

#define MDL_SET_OUTPUT_PORT_DIMENSION_INFO 
static void mdlSetOutputPortDimensionInfo(SimStruct *S, int_T port, 
										 const DimsInfo_T *dimsInfo) 
{
	//there are no DYNAMICALLY_SIZED output ports
	ssSetErrorStatus(S, "Unexpected DYNAMICALLY_SIZED parameter index\n");
}

#define MDL_SET_DEFAULT_PORT_DIMENSION_INFO
static void mdlSetDefaultPortDimensionInfo(SimStruct *S) 
{
	DECL_AND_INIT_DIMSINFO(di);
	int_T dims;
	//if there is any problem setting the input port to the requested size,
	//fall back to a size of 1
	di.numDims = 1;
	dims = 1;
	di.dims = &dims;
	di.width = 1;
	ssSetInputPortDimensionInfo(S, IN_DATA_IDX, &di);
}


static void mdlInitializeSampleTimes(SimStruct *S)
{
	ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
	ssSetOffsetTime(S, 0, 0.0);
	ssSetModelReferenceSampleTimeDefaultInheritance(S);
}

static void mdlOutputs(SimStruct *S, int_T tid)
{
	gchar uri_string[256];
	gchar ip_string[256];
	GError* tmperr = NULL;

	//fetch device
	gt_rt_udp_socket* device = GT_RT_DEVICE(S);
	//fetch hostname
	gchar *hostname;



	//fetch pointers to the input signals
	InputUInt8PtrsType ip = (InputUInt8PtrsType)ssGetInputPortSignalPtrs(S, IN_IP_IDX); 
	InputUInt16PtrsType port = (InputUInt16PtrsType)ssGetInputPortSignalPtrs(S, IN_PORT_IDX);
	InputUInt8PtrsType data = (InputUInt8PtrsType)ssGetInputPortSignalPtrs(S, IN_DATA_IDX); 
	InputUInt32PtrsType len = (InputUInt32PtrsType)ssGetInputPortSignalPtrs(S, IN_LEN_IDX);


	//fetch pointers to the output signal
	gint32* err = (gint32*)ssGetOutputPortSignal(S, OUT_ERR_IDX);

	guint16 port_parameter;
	guint8 *data_parameter;
	guint32 len_parameter;
	UNUSED_ARG(tid);
	hostname = HOSTNAME_STORAGE(S);
	
	*err = 0;
	//save device in work vector when function is called for the first time
	if (device == NULL) {
		mxGetString(URI_PARAM(S), uri_string, sizeof(uri_string) - 1);
		device = gt_rt_udp_socket_get(uri_string, &tmperr);
		if (tmperr == NULL) {
			ssSetPWorkValue(S, GT_RT_DEVICE_IDX, device); 
		} else {
			*err = tmperr->code;
		}
	}

	if (hostname == NULL) {

		hostname = g_new(gchar, HOSTNAME_STORAGE_LEN);
		mxGetString(HOSTNAME_PARAM(S), hostname, HOSTNAME_STORAGE_LEN);
		ssSetPWorkValue(S, HOSTNAME_STORAGE_IDX, hostname);
	}

	if (tmperr == NULL) {
		if (*len[0] > (guint32)ssGetInputPortWidth(S, IN_DATA_IDX)) {
			g_print("len: %i, port: %i\n", *len[0], (guint32)ssGetInputPortWidth(S, IN_DATA_IDX));
			*err = 255;
		} else {
			if (strlen(hostname) == 0) {
				sprintf(ip_string, "%u.%u.%u.%u", *ip[0], *ip[1], *ip[2], *ip[3]);
				hostname = ip_string;
			}
			port_parameter = (guint16) *port[0];
			data_parameter = (guint8 *) *data;
			len_parameter = (guint32) *len[0];
			gt_rt_udp_socket_send(device, hostname, port_parameter, data_parameter, len_parameter, &tmperr);
			if (tmperr != NULL) {
				*err = tmperr->code;
			}
		}
	}
}

static void mdlTerminate(SimStruct *S)
{
	gchar *hostname;
	if (ssGetPWork(S) != NULL) {
		ssSetPWorkValue(S, GT_RT_DEVICE_IDX, NULL);
		//fetch and free hostname
		hostname = HOSTNAME_STORAGE(S);
		free(hostname);
		ssSetPWorkValue(S, HOSTNAME_STORAGE_IDX, NULL);
	}
}


#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
